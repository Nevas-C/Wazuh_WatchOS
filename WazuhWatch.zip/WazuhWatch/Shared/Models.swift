//
//  Models.swift
//  Shared (add to BOTH the iOS and watchOS targets)
//

import Foundation

// MARK: - Severity

/// Wazuh rule levels run 0...15. We bucket them for display/notification purposes.
enum AlertSeverity: Int, Codable, Comparable, CaseIterable {
    case low = 0        // 0-6
    case medium = 1     // 7-11
    case high = 2       // 12-14
    case critical = 3   // 15

    static func from(level: Int) -> AlertSeverity {
        switch level {
        case ..<7: return .low
        case 7..<12: return .medium
        case 12..<15: return .high
        default: return .critical
        }
    }

    var label: String {
        switch self {
        case .low: return "Low"
        case .medium: return "Medium"
        case .high: return "High"
        case .critical: return "Critical"
        }
    }

    static func < (lhs: AlertSeverity, rhs: AlertSeverity) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}

// MARK: - Agent

enum AgentStatus: String, Codable {
    case active
    case disconnected
    case pending
    case neverConnected = "never_connected"
    case unknown

    init(rawValueLoose value: String) {
        self = AgentStatus(rawValue: value) ?? .unknown
    }
}

struct WazuhAgent: Codable, Identifiable, Hashable {
    var id: String          // Wazuh agent id, e.g. "001"
    var name: String
    var ip: String?
    var status: AgentStatus
    var osName: String?
    var lastKeepAlive: Date?
}

struct AgentSummary: Codable, Equatable {
    var connected: Int
    var disconnected: Int
    var neverConnected: Int
    var pending: Int

    var total: Int { connected + disconnected + neverConnected + pending }

    static let empty = AgentSummary(connected: 0, disconnected: 0, neverConnected: 0, pending: 0)
}

// MARK: - Alert

struct WazuhAlert: Codable, Identifiable, Hashable {
    var id: String                  // document id from the indexer
    var ruleId: Int
    var ruleDescription: String
    var level: Int
    var agentId: String
    var agentName: String
    var timestamp: Date
    var fullLog: String?

    var severity: AlertSeverity { AlertSeverity.from(level: level) }
}

// MARK: - Dashboard snapshot (this is the payload relayed to the watch)

struct DashboardSnapshot: Codable {
    var agentSummary: AgentSummary
    var agents: [WazuhAgent]           // trimmed list, see PollingCoordinator
    var alertCounts: [String: Int]     // keyed by AlertSeverity.label
    var recentAlerts: [WazuhAlert]     // most recent N, newest first
    var lastUpdated: Date

    static let empty = DashboardSnapshot(
        agentSummary: .empty,
        agents: [],
        alertCounts: [:],
        recentAlerts: [],
        lastUpdated: .distantPast
    )
}
