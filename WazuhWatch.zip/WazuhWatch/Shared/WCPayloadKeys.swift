//
//  WCPayloadKeys.swift
//  Shared (add to BOTH the iOS and watchOS targets)
//
//  Central place for the dictionary keys/types passed over WatchConnectivity,
//  so the two targets can't drift out of sync.
//

import Foundation

enum WCMessageType: String, Codable {
    case dashboardSnapshot      // full snapshot: agents + counts + recent alerts
    case highSeverityAlert      // a single alert that should trigger a watch notification
    case requestRefresh         // watch -> phone: "poll Wazuh now and send me fresh data"
}

enum WCKey {
    static let type = "type"
    static let payload = "payload"
}

/// Helper to encode/decode any Codable payload into the [String: Any] shape
/// required by WCSession's sendMessage / updateApplicationContext / transferUserInfo.
enum WCEnvelope {
    static func encode<T: Encodable>(type: WCMessageType, payload: T) -> [String: Any] {
        let data = (try? JSONEncoder().encode(payload)) ?? Data()
        return [
            WCKey.type: type.rawValue,
            WCKey.payload: data
        ]
    }

    static func decodeType(from dict: [String: Any]) -> WCMessageType? {
        guard let raw = dict[WCKey.type] as? String else { return nil }
        return WCMessageType(rawValue: raw)
    }

    static func decodePayload<T: Decodable>(_ type: T.Type, from dict: [String: Any]) -> T? {
        guard let data = dict[WCKey.payload] as? Data else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(T.self, from: data)
    }
}
