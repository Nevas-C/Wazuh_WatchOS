//
//  KeychainHelper.swift
//  iOS target only (the watch never touches Wazuh credentials directly)
//

import Foundation
import Security

enum KeychainHelper {
    static func save(_ value: String, service: String, account: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary) // overwrite
        var attributes = query
        attributes[kSecValueData as String] = data
        SecItemAdd(attributes as CFDictionary, nil)
    }

    static func read(service: String, account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(service: String, account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

/// Convenience wrapper for the specific values this app stores.
enum WazuhCredentialStore {
    private static let service = "com.yourorg.wazuhwatch.credentials"

    static var managerHost: String? {
        get { KeychainHelper.read(service: service, account: "managerHost") }
        set { newValue.map { KeychainHelper.save($0, service: service, account: "managerHost") } }
    }
    static var indexerHost: String? {
        get { KeychainHelper.read(service: service, account: "indexerHost") }
        set { newValue.map { KeychainHelper.save($0, service: service, account: "indexerHost") } }
    }
    static var username: String? {
        get { KeychainHelper.read(service: service, account: "username") }
        set { newValue.map { KeychainHelper.save($0, service: service, account: "username") } }
    }
    static var password: String? {
        get { KeychainHelper.read(service: service, account: "password") }
        set { newValue.map { KeychainHelper.save($0, service: service, account: "password") } }
    }
    /// Rule-level (0-15) at/above which we treat an alert as "high severity" for notifications.
    static var severityThreshold: Int {
        get {
            let v = UserDefaults.standard.integer(forKey: "severityThreshold")
            return v == 0 ? 12 : v // default to 12 (== AlertSeverity.high)
        }
        set { UserDefaults.standard.set(newValue, forKey: "severityThreshold") }
    }
    static var isConfigured: Bool {
        managerHost != nil && username != nil && password != nil
    }
}
