# Wazuh Watch — setup guide

This bundle contains **source files only** — I can't generate a compiled
`.xcodeproj` from here. Follow the steps below in Xcode (needs a Mac,
Xcode 15+, and Apple Watch paired to an iPhone with watchOS 9+).

## 1. Create the project

1. Xcode → File → New → Project → **iOS → App**.
   - Product Name: `WazuhWatch`
   - Interface: SwiftUI, Language: Swift
   - Uncheck "Include Tests" if you don't need them.
2. With the project open: File → New → Target → **watchOS → Watch App**.
   - Xcode will offer "Watch App for existing iOS App" — pick that, name it
     `WazuhWatch Watch App`, and let it pair to the iOS target automatically.
   - This creates two targets: `WazuhWatch` (iPhone) and `WazuhWatch Watch App` (Watch),
     already linked as companion apps.
3. Delete the placeholder `ContentView.swift` files Xcode generated in both
   targets — this bundle provides replacements.

## 2. Add the files, to the right targets

In Xcode's target membership checkboxes (File Inspector, right-hand panel),
add files as follows:

| Folder here          | Add to target(s)                        |
|-----------------------|------------------------------------------|
| `Shared/*.swift`       | **Both** `WazuhWatch` and `WazuhWatch Watch App` |
| `iOSApp/*.swift`       | `WazuhWatch` (iPhone) only               |
| `WatchApp/*.swift`     | `WazuhWatch Watch App` only              |

Drag each folder into the corresponding Xcode group, and when prompted,
check the correct target(s) per the table above.

## 3. Capabilities & Info.plist

**iOS target** (`WazuhWatch`):
- Signing & Capabilities → **+ Capability → Background Modes** → check
  **Background fetch** and **Background processing**.
- Info tab → add key `Permitted background task scheduler identifiers`
  (array) → add string `com.yourorg.wazuhwatch.refresh` (must match
  `BackgroundRefreshManager.taskIdentifier` — change both together if you
  rename it).
- Add `Privacy - User Notifications Usage Description` if prompted (not
  strictly required for local notifications, but Xcode sometimes flags it).

**watchOS target** (`WazuhWatch Watch App`):
- No extra background mode is needed — receiving WatchConnectivity
  messages/application context and posting a local notification works
  without it, as long as the watch app hasn't been force-quit by the user.

## 4. Bundle identifiers

Both targets must share the same prefix, e.g.:
- `com.yourorg.wazuhwatch` (iPhone)
- `com.yourorg.wazuhwatch.watchkitapp` (Watch — Xcode sets this automatically)

Update the `subsystem` strings in the `Logger(...)` calls and the
`taskIdentifier` in `BackgroundRefreshManager.swift` to match your actual
bundle ID if you change it from `com.yourorg.wazuhwatch`.

## 5. Wazuh-side setup

You'll need:
- **Manager API** (default port `55000`) reachable from your iPhone, with a
  user that has at least read access to `/agents*` and
  `/security/user/authenticate`.
- **Indexer API** (default port `9200`, OpenSearch) reachable from your
  iPhone, for querying `wazuh-alerts-*`. If you don't want to expose the
  indexer to the internet directly, put a small reverse proxy in front of it
  and point `indexerHost` at that instead — the request shape in
  `WazuhIndexerClient.swift` doesn't need to change.
- Both endpoints need to be reachable wherever your phone is (VPN, Tailscale,
  a public reverse proxy with auth, etc.) since polling happens from the
  device, not a server.

Enter both hosts + a username/password in the iPhone app's **Settings** tab
after building. Credentials are stored in the iOS Keychain, not synced to
the watch — the watch only ever receives already-fetched dashboard data.

## 6. How the pieces fit together

```
Wazuh Manager API  ───┐
                       ├──► iPhone app (PollingCoordinator) ──► WatchConnectivity ──► Watch app
Wazuh Indexer API  ───┘         │                                                        │
                                 ▼                                                        ▼
                     Local notification (iPhone)                         Local notification (Watch)
```

- The iPhone polls in the foreground (on launch / pull-to-refresh) and in
  the background via `BGAppRefreshTask` (opportunistic, ~every 15-30+ min,
  at the system's discretion — this is a hard OS limit, not something the
  code can tighten).
- On finding a new alert at/above your configured severity threshold, the
  iPhone fires its own notification **and** relays the alert to the watch
  via `WCSession.sendMessage` (instant, if reachable) or
  `transferUserInfo` (queued, delivered when the watch next wakes).
- The full dashboard snapshot (agent counts, agent list, 24h severity
  counts, recent alerts) is pushed via `updateApplicationContext`, which
  always holds just the latest value — the watch app shows whatever it
  last received, no re-fetch needed to open the app.
- Pull-to-refresh in any watch tab sends a `requestRefresh` message back to
  the phone, which triggers an immediate poll.

## 7. Known limitations to be upfront about

- **Not truly real-time.** Without your own APNs push backend, the fastest
  path from "Wazuh generates an alert" to "watch notification" is bounded
  by how often the iPhone app polls — instant if the iPhone app is open,
  otherwise it rides on iOS's background refresh scheduling. If you need
  guaranteed near-real-time delivery, the next step up is a small server
  that watches Wazuh and sends APNs pushes directly to the watch — happy to
  build that layer out if you want it.
- The self-signed TLS trust in `InsecureTrustDelegate` trusts *any*
  certificate presented by the configured hosts. Fine for a manager you
  control on a private network; replace with certificate pinning before
  exposing this more broadly.
- `fetchSeverityCounts()` pulls up to 1000 recent alerts and buckets them
  client-side rather than using an OpenSearch aggregation query — simple or
  now, but worth replacing with a real `date_histogram`/`terms` aggregation
  if your alert volume is high.
