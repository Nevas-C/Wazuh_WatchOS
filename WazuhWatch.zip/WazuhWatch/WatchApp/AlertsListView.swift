//
//  AlertsListView.swift
//  watchOS target only
//

import SwiftUI

struct AlertsListView: View {
    @ObservedObject private var connectivity = WatchConnectivityManager.shared

    var body: some View {
        NavigationStack {
            List {
                Section("Recent alerts") {
                    if connectivity.snapshot.recentAlerts.isEmpty {
                        Text("No alerts yet").foregroundStyle(.secondary).font(.footnote)
                    }
                    ForEach(connectivity.snapshot.recentAlerts) { alert in
                        NavigationLink(destination: AlertDetailView(alert: alert)) {
                            AlertRow(alert: alert)
                        }
                    }
                }
            }
            .listStyle(.carousel)
            .refreshable { connectivity.requestRefresh() }
            .navigationTitle("Alerts")
        }
    }
}

private struct AlertRow: View {
    let alert: WazuhAlert

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Circle().fill(color).frame(width: 7, height: 7)
                Text(alert.severity.label).font(.caption2).foregroundStyle(color)
                Spacer()
                Text(alert.timestamp, style: .time).font(.caption2).foregroundStyle(.secondary)
            }
            Text(alert.ruleDescription).font(.footnote).lineLimit(2)
            Text(alert.agentName).font(.caption2).foregroundStyle(.secondary)
        }
    }

    private var color: Color {
        switch alert.severity {
        case .low: return .gray
        case .medium: return .yellow
        case .high: return .orange
        case .critical: return .red
        }
    }
}

struct AlertDetailView: View {
    let alert: WazuhAlert

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text(alert.ruleDescription).font(.headline)
                LabeledContent("Severity", value: alert.severity.label)
                LabeledContent("Rule level", value: "\(alert.level)")
                LabeledContent("Rule ID", value: "\(alert.ruleId)")
                LabeledContent("Agent", value: alert.agentName)
                LabeledContent("Time", value: alert.timestamp.formatted(date: .abbreviated, time: .standard))
                if let log = alert.fullLog {
                    Divider()
                    Text("Full log").font(.caption).foregroundStyle(.secondary)
                    Text(log).font(.caption2).textSelection(.enabled)
                }
            }
            .padding(.horizontal, 4)
        }
        .navigationTitle("Alert")
    }
}

#Preview {
    NavigationStack {
        AlertsListView()
    }
}
