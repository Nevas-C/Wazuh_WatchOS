//
//  DashboardView.swift
//  watchOS target only
//

import SwiftUI

struct DashboardView: View {
    @ObservedObject private var connectivity = WatchConnectivityManager.shared

    private var snapshot: DashboardSnapshot { connectivity.snapshot }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Wazuh").font(.headline)

                agentSummaryCard

                Divider()

                Text("Alerts (24h)").font(.subheadline).foregroundStyle(.secondary)
                ForEach(AlertSeverity.allCases.reversed(), id: \.self) { sev in
                    HStack {
                        Circle().fill(color(for: sev)).frame(width: 8, height: 8)
                        Text(sev.label)
                        Spacer()
                        Text("\(snapshot.alertCounts[sev.label] ?? 0)").bold()
                    }
                    .font(.footnote)
                }

                if !snapshot.agentSummary.equalsEmpty {
                    Text("Updated \(snapshot.lastUpdated, style: .relative) ago")
                        .font(.caption2).foregroundStyle(.secondary)
                        .padding(.top, 4)
                } else {
                    Text("No data yet — open the Wazuh Watch app on your iPhone.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 4)
        }
        .refreshable {
            connectivity.requestRefresh()
        }
    }

    private var agentSummaryCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Label("\(snapshot.agentSummary.connected)", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                Spacer()
                Label("\(snapshot.agentSummary.disconnected)", systemImage: "xmark.circle.fill")
                    .foregroundStyle(.red)
            }
            .font(.title3.bold())
            Text("connected / disconnected agents").font(.caption2).foregroundStyle(.secondary)
        }
    }

    private func color(for severity: AlertSeverity) -> Color {
        switch severity {
        case .low: return .gray
        case .medium: return .yellow
        case .high: return .orange
        case .critical: return .red
        }
    }
}

private extension AgentSummary {
    var equalsEmpty: Bool { self == AgentSummary.empty }
}

#Preview {
    DashboardView()
}
