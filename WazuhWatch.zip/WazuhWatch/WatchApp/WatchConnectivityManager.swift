//
//  WatchConnectivityManager.swift
//  watchOS target only
//

import Foundation
import WatchConnectivity
import UserNotifications

final class WatchConnectivityManager: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = WatchConnectivityManager()

    @Published var snapshot: DashboardSnapshot = .empty
    @Published var phoneIsReachable = false

    func activate() {
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
    }

    /// Pull-to-refresh: ask the phone to poll Wazuh right now.
    func requestRefresh() {
        let payload = WCEnvelope.encode(type: .requestRefresh, payload: true)
        let session = WCSession.default
        if session.isReachable {
            session.sendMessage(payload, replyHandler: nil, errorHandler: nil)
        } else {
            session.transferUserInfo(payload)
        }
    }

    // MARK: WCSessionDelegate

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async { self.phoneIsReachable = session.isReachable }
        // Pick up whatever the phone last set, even if we were inactive when it was sent.
        let latest = session.applicationContext
        if !latest.isEmpty {
            handle(payload: latest)
        }
    }

    func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async { self.phoneIsReachable = session.isReachable }
    }

    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        handle(payload: applicationContext)
    }

    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        handle(payload: message)
    }

    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        handle(payload: userInfo)
    }

    private func handle(payload: [String: Any]) {
        guard let type = WCEnvelope.decodeType(from: payload) else { return }
        switch type {
        case .dashboardSnapshot:
            guard let snap = WCEnvelope.decodePayload(DashboardSnapshot.self, from: payload) else { return }
            DispatchQueue.main.async { self.snapshot = snap }

        case .highSeverityAlert:
            guard let alert = WCEnvelope.decodePayload(WazuhAlert.self, from: payload) else { return }
            WatchNotificationManager.shared.postAlertNotification(for: alert)
            // Also fold it into the in-memory snapshot so the Alerts list updates immediately.
            DispatchQueue.main.async {
                if !self.snapshot.recentAlerts.contains(where: { $0.id == alert.id }) {
                    self.snapshot.recentAlerts.insert(alert, at: 0)
                    self.snapshot.alertCounts[alert.severity.label, default: 0] += 1
                }
            }

        case .requestRefresh:
            break // phone-only message
        }
    }
}
