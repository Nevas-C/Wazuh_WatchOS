//
//  AgentsView.swift
//  watchOS target only
//

import SwiftUI

struct AgentsView: View {
    @ObservedObject private var connectivity = WatchConnectivityManager.shared

    var body: some View {
        List {
            Section("Agents (\(connectivity.snapshot.agents.count))") {
                if connectivity.snapshot.agents.isEmpty {
                    Text("No agent data").foregroundStyle(.secondary).font(.footnote)
                }
                ForEach(connectivity.snapshot.agents) { agent in
                    HStack {
                        Circle()
                            .fill(agent.status == .active ? .green : .red)
                            .frame(width: 8, height: 8)
                        VStack(alignment: .leading) {
                            Text(agent.name).font(.footnote)
                            Text(agent.status.rawValue.capitalized)
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .listStyle(.carousel)
        .refreshable { connectivity.requestRefresh() }
    }
}

#Preview {
    AgentsView()
}
