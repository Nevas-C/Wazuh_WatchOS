//
//  WazuhWatchApp.swift
//  watchOS target only — this is the @main entry point for the WATCH app.
//

import SwiftUI

@main
struct WazuhWatchApp: App {
    init() {
        WatchConnectivityManager.shared.activate()
        WatchNotificationManager.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            WatchRootView()
        }
    }
}

struct WatchRootView: View {
    var body: some View {
        TabView {
            DashboardView()
            AgentsView()
            AlertsListView()
        }
        .tabViewStyle(.page)
    }
}
