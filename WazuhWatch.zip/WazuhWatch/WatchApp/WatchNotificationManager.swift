//
//  WatchNotificationManager.swift
//  watchOS target only
//

import Foundation
import UserNotifications

final class WatchNotificationManager {
    static let shared = WatchNotificationManager()

    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    func postAlertNotification(for alert: WazuhAlert) {
        let content = UNMutableNotificationContent()
        content.title = "\(alert.severity.label) severity — \(alert.agentName)"
        content.body = alert.ruleDescription
        content.sound = .default

        let request = UNNotificationRequest(identifier: alert.id, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}
