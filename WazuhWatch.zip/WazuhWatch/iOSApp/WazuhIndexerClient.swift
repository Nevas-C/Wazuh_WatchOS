//
//  WazuhIndexerClient.swift
//  iOS target only
//
//  Alert *content* (rule, level, agent, full_log, timestamp) lives in the
//  Wazuh Indexer (OpenSearch), not the Manager API — the same place the
//  Wazuh dashboard reads from. Default port 9200, basic auth.
//
//  If you'd rather not expose the indexer directly to the phone, point
//  `indexerHost` at a small reverse-proxy / API gateway you control instead;
//  the request shape below (POST <host>/wazuh-alerts-*/_search) is unchanged.
//

import Foundation

actor WazuhIndexerClient {
    private lazy var session: URLSession = {
        URLSession(configuration: .ephemeral, delegate: InsecureTrustDelegate(), delegateQueue: nil)
    }()

    private func baseURL() throws -> URL {
        guard let host = WazuhCredentialStore.indexerHost, let url = URL(string: host) else {
            throw WazuhAPIError.notConfigured
        }
        return url
    }

    /// Fetches the most recent alerts at or above `minLevel`, newest first.
    func fetchRecentAlerts(minLevel: Int, size: Int = 25) async throws -> [WazuhAlert] {
        guard let user = WazuhCredentialStore.username, let pass = WazuhCredentialStore.password else {
            throw WazuhAPIError.notConfigured
        }
        let url = try baseURL().appendingPathComponent("wazuh-alerts-*/_search")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let basic = Data("\(user):\(pass)".utf8).base64EncodedString()
        request.setValue("Basic \(basic)", forHTTPHeaderField: "Authorization")

        let body: [String: Any] = [
            "size": size,
            "sort": [["timestamp": "desc"]],
            "query": [
                "range": ["rule.level": ["gte": minLevel]]
            ]
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw WazuhAPIError.badResponse(code, String(data: data, encoding: .utf8) ?? "")
        }

        struct SearchResponse: Decodable {
            struct Hits: Decodable {
                struct Hit: Decodable {
                    struct Source: Decodable {
                        struct Rule: Decodable { let id: Int; let description: String; let level: Int }
                        struct Agent: Decodable { let id: String; let name: String }
                        let rule: Rule
                        let agent: Agent
                        let timestamp: String
                        let full_log: String?
                    }
                    let _id: String
                    let _source: Source
                }
                let hits: [Hit]
            }
            let hits: Hits
        }

        do {
            let decoded = try JSONDecoder().decode(SearchResponse.self, from: data)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            return decoded.hits.hits.map { hit in
                let s = hit._source
                let date = formatter.date(from: s.timestamp) ?? ISO8601DateFormatter().date(from: s.timestamp) ?? Date()
                return WazuhAlert(id: hit._id, ruleId: s.rule.id, ruleDescription: s.rule.description,
                                   level: s.rule.level, agentId: s.agent.id, agentName: s.agent.name,
                                   timestamp: date, fullLog: s.full_log)
            }
        } catch {
            throw WazuhAPIError.decoding(error)
        }
    }

    /// Counts alerts in the last 24h bucketed into the four severity labels.
    func fetchSeverityCounts(hoursBack: Int = 24) async throws -> [String: Int] {
        // Simple approach: pull a reasonably large recent window and bucket client-side.
        // For high-volume environments, replace with a proper aggregation query.
        let alerts = try await fetchRecentAlerts(minLevel: 0, size: 1000)
        let cutoff = Date().addingTimeInterval(-Double(hoursBack) * 3600)
        var counts: [String: Int] = ["Low": 0, "Medium": 0, "High": 0, "Critical": 0]
        for a in alerts where a.timestamp >= cutoff {
            counts[a.severity.label, default: 0] += 1
        }
        return counts
    }
}
