//
//  WazuhManagerAPIClient.swift
//  iOS target only
//
//  Talks to the Wazuh Manager REST API (default port 55000).
//  Docs: https://documentation.wazuh.com/current/user-manual/api/reference.html
//
//  NOTE: the Manager API gives you agents, rules, manager stats, etc. — but it
//  does NOT expose alert *content* (that lives in the Wazuh Indexer / OpenSearch,
//  see WazuhIndexerClient.swift). This client only handles the agent side.
//

import Foundation

enum WazuhAPIError: Error, LocalizedError {
    case notConfigured
    case authFailed(String)
    case badResponse(Int, String)
    case decoding(Error)

    var errorDescription: String? {
        switch self {
        case .notConfigured: return "Wazuh host/credentials are not configured."
        case .authFailed(let msg): return "Wazuh authentication failed: \(msg)"
        case .badResponse(let code, let msg): return "Wazuh API error \(code): \(msg)"
        case .decoding(let e): return "Failed to decode Wazuh response: \(e.localizedDescription)"
        }
    }
}

actor WazuhManagerAPIClient {
    private var cachedToken: String?
    private var tokenExpiry: Date = .distantPast

    /// Accepts self-signed certs, which Wazuh managers commonly use out of the box.
    /// Swap in a pinned-cert URLSessionDelegate before shipping to production.
    private lazy var session: URLSession = {
        URLSession(configuration: .ephemeral, delegate: InsecureTrustDelegate(), delegateQueue: nil)
    }()

    private func baseURL() throws -> URL {
        guard let host = WazuhCredentialStore.managerHost, let url = URL(string: host) else {
            throw WazuhAPIError.notConfigured
        }
        return url
    }

    /// Authenticates via Basic auth against /security/user/authenticate and caches the JWT.
    private func authenticatedToken() async throws -> String {
        if let token = cachedToken, Date() < tokenExpiry {
            return token
        }
        guard let user = WazuhCredentialStore.username, let pass = WazuhCredentialStore.password else {
            throw WazuhAPIError.notConfigured
        }
        let base = try baseURL()
        var request = URLRequest(url: base.appendingPathComponent("security/user/authenticate"))
        request.httpMethod = "POST"
        let basic = Data("\(user):\(pass)".utf8).base64EncodedString()
        request.setValue("Basic \(basic)", forHTTPHeaderField: "Authorization")

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw WazuhAPIError.authFailed("HTTP \(code)")
        }
        struct AuthResponse: Decodable { struct D: Decodable { let token: String }; let data: D }
        let decoded = try JSONDecoder().decode(AuthResponse.self, from: data)
        cachedToken = decoded.data.token
        // Wazuh JWTs default to a 15 minute lifetime; refresh a bit early.
        tokenExpiry = Date().addingTimeInterval(13 * 60)
        return decoded.data.token
    }

    private func authorizedRequest(path: String, query: [URLQueryItem] = []) async throws -> URLRequest {
        let token = try await authenticatedToken()
        var components = URLComponents(url: try baseURL().appendingPathComponent(path), resolvingAgainstBaseURL: false)!
        components.queryItems = query.isEmpty ? nil : query
        var request = URLRequest(url: components.url!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        return request
    }

    /// GET /agents/summary/status
    func fetchAgentSummary() async throws -> AgentSummary {
        let request = try await authorizedRequest(path: "agents/summary/status")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw WazuhAPIError.badResponse(code, String(data: data, encoding: .utf8) ?? "")
        }
        struct SummaryResponse: Decodable {
            struct Data: Decodable {
                struct Connection: Decodable {
                    let active: Int
                    let disconnected: Int
                    let neverConnected: Int
                    let pending: Int
                    enum CodingKeys: String, CodingKey {
                        case active, disconnected, pending
                        case neverConnected = "never_connected"
                    }
                }
                let connection: Connection
            }
            let data: Data
        }
        do {
            let decoded = try JSONDecoder().decode(SummaryResponse.self, from: data)
            let c = decoded.data.connection
            return AgentSummary(connected: c.active, disconnected: c.disconnected,
                                 neverConnected: c.neverConnected, pending: c.pending)
        } catch {
            throw WazuhAPIError.decoding(error)
        }
    }

    /// GET /agents (paginated list, used for the Agents tab)
    func fetchAgents(limit: Int = 200) async throws -> [WazuhAgent] {
        let request = try await authorizedRequest(path: "agents", query: [
            URLQueryItem(name: "limit", value: String(limit)),
            URLQueryItem(name: "select", value: "id,name,ip,status,os,lastKeepAlive")
        ])
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw WazuhAPIError.badResponse(code, String(data: data, encoding: .utf8) ?? "")
        }
        struct AgentsResponse: Decodable {
            struct Data: Decodable {
                struct AffectedItem: Decodable {
                    let id: String
                    let name: String
                    let ip: String?
                    let status: String
                    struct OS: Decodable { let name: String? }
                    let os: OS?
                    let lastKeepAlive: String?
                    enum CodingKeys: String, CodingKey {
                        case id, name, ip, status, os
                        case lastKeepAlive = "lastKeepAlive"
                    }
                }
                let affectedItems: [AffectedItem]
                enum CodingKeys: String, CodingKey { case affectedItems = "affected_items" }
            }
            let data: Data
        }
        do {
            let decoded = try JSONDecoder().decode(AgentsResponse.self, from: data)
            let formatter = ISO8601DateFormatter()
            return decoded.data.affectedItems.map {
                WazuhAgent(id: $0.id, name: $0.name, ip: $0.ip,
                           status: AgentStatus(rawValueLoose: $0.status),
                           osName: $0.os?.name,
                           lastKeepAlive: $0.lastKeepAlive.flatMap { formatter.date(from: $0) })
            }
        } catch {
            throw WazuhAPIError.decoding(error)
        }
    }
}

/// Trusts self-signed certs from your own Wazuh manager. Only use this against
/// a host you control; do not ship an app that blindly trusts arbitrary hosts.
final class InsecureTrustDelegate: NSObject, URLSessionDelegate {
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                     completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        guard let trust = challenge.protectionSpace.serverTrust else {
            completionHandler(.performDefaultHandling, nil)
            return
        }
        completionHandler(.useCredential, URLCredential(trust: trust))
    }
}
