//
//  WazuhWatchCompanionApp.swift
//  iOS target only — this is the @main entry point for the PHONE app.
//

import SwiftUI
import BackgroundTasks

@main
struct WazuhWatchCompanionApp: App {
    init() {
        BackgroundRefreshManager.register()
        PhoneConnectivityManager.shared.activate()
        LocalNotificationManager.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear { BackgroundRefreshManager.schedule() }
        }
    }
}
