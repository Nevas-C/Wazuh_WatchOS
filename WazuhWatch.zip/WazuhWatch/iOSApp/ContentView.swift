//
//  ContentView.swift
//  iOS target only
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            StatusView()
                .tabItem { Label("Status", systemImage: "shield.checkerboard") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
    }
}

struct StatusView: View {
    @ObservedObject private var polling = PollingCoordinator.shared
    @ObservedObject private var connectivity = PhoneConnectivityManager.shared

    var body: some View {
        NavigationView {
            List {
                Section("Watch") {
                    Label(connectivity.watchIsReachable ? "Reachable" : "Not reachable",
                          systemImage: connectivity.watchIsReachable ? "applewatch.radiowaves.left.and.right" : "applewatch.slash")
                }
                Section("Agents") {
                    LabeledContent("Connected", value: "\(polling.lastSnapshot.agentSummary.connected)")
                    LabeledContent("Disconnected", value: "\(polling.lastSnapshot.agentSummary.disconnected)")
                    LabeledContent("Never connected", value: "\(polling.lastSnapshot.agentSummary.neverConnected)")
                }
                Section("Alerts (last 24h)") {
                    ForEach(AlertSeverity.allCases, id: \.self) { sev in
                        LabeledContent(sev.label, value: "\(polling.lastSnapshot.alertCounts[sev.label] ?? 0)")
                    }
                }
                if let error = polling.lastError {
                    Section("Last error") {
                        Text(error).foregroundStyle(.red).font(.footnote)
                    }
                }
                Section {
                    Text("Last updated: \(polling.lastSnapshot.lastUpdated, style: .relative) ago")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Wazuh Watch")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        Task { await polling.pollOnce(reason: "manual refresh") }
                    } label: {
                        if polling.isPolling { ProgressView() } else { Image(systemName: "arrow.clockwise") }
                    }
                }
            }
            .task { await polling.pollOnce(reason: "view appeared") }
        }
    }
}

#Preview {
    ContentView()
}
