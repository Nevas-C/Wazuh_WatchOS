//
//  PollingCoordinator.swift
//  iOS target only
//
//  Single place that: authenticates to Wazuh, fetches agent + alert state,
//  detects new high-severity alerts, fires the iPhone notification, and
//  relays everything to the watch. Called from the UI's manual refresh
//  button, BackgroundRefreshManager's scheduled task, and the watch's
//  pull-to-refresh request.
//

import Foundation
import os.log

@MainActor
final class PollingCoordinator: ObservableObject {
    static let shared = PollingCoordinator()

    @Published var lastSnapshot: DashboardSnapshot = .empty
    @Published var lastError: String?
    @Published var isPolling = false

    private let managerClient = WazuhManagerAPIClient()
    private let indexerClient = WazuhIndexerClient()
    private let log = Logger(subsystem: "com.yourorg.wazuhwatch", category: "Polling")

    /// IDs of alerts we've already notified on, so we don't re-notify every poll.
    private var seenHighSeverityAlertIDs: Set<String> = []

    func pollOnce(reason: String) async {
        guard WazuhCredentialStore.isConfigured else {
            lastError = "Not configured — set your Wazuh host and credentials in Settings."
            return
        }
        isPolling = true
        defer { isPolling = false }
        log.info("Polling Wazuh (\(reason, privacy: .public))")

        do {
            async let summary = managerClient.fetchAgentSummary()
            async let agents = managerClient.fetchAgents()
            async let counts = indexerClient.fetchSeverityCounts()
            async let recent = indexerClient.fetchRecentAlerts(minLevel: 0, size: 25)

            // Non-active agents are usually the interesting ones to see on a small
            // screen; cap the list so the WatchConnectivity payload stays small.
            let allAgents = try await agents
            let trimmedAgents = allAgents
                .sorted { ($0.status == .active ? 1 : 0) < ($1.status == .active ? 1 : 0) }
                .prefix(50)

            let snapshot = DashboardSnapshot(
                agentSummary: try await summary,
                agents: Array(trimmedAgents),
                alertCounts: try await counts,
                recentAlerts: try await recent,
                lastUpdated: Date()
            )
            lastSnapshot = snapshot
            lastError = nil

            PhoneConnectivityManager.shared.pushSnapshot(snapshot)
            await handleNewHighSeverityAlerts(in: snapshot.recentAlerts)

        } catch {
            lastError = error.localizedDescription
            log.error("Poll failed: \(error.localizedDescription, privacy: .public)")
        }
    }

    private func handleNewHighSeverityAlerts(in alerts: [WazuhAlert]) async {
        let threshold = WazuhCredentialStore.severityThreshold
        let newHighSeverity = alerts.filter { $0.level >= threshold && !seenHighSeverityAlertIDs.contains($0.id) }
        guard !newHighSeverity.isEmpty else { return }

        for alert in newHighSeverity.sorted(by: { $0.timestamp < $1.timestamp }) {
            seenHighSeverityAlertIDs.insert(alert.id)
            LocalNotificationManager.shared.postAlertNotification(for: alert)
            PhoneConnectivityManager.shared.notifyHighSeverityAlert(alert)
        }
        // Keep the de-dupe set from growing forever.
        if seenHighSeverityAlertIDs.count > 500 {
            seenHighSeverityAlertIDs = Set(alerts.prefix(200).map { $0.id })
        }
    }
}
