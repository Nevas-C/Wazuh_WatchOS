//
//  PhoneConnectivityManager.swift
//  iOS target only
//

import Foundation
import WatchConnectivity
import os.log

final class PhoneConnectivityManager: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = PhoneConnectivityManager()
    private let log = Logger(subsystem: "com.yourorg.wazuhwatch", category: "WCPhone")

    @Published var watchIsReachable = false

    func activate() {
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
    }

    // MARK: Sending

    /// Sends the full dashboard snapshot. Uses updateApplicationContext so the
    /// watch always has the *latest* state even if it wasn't reachable when we sent it
    /// (older contexts are simply overwritten, which is what we want here).
    func pushSnapshot(_ snapshot: DashboardSnapshot) {
        let payload = WCEnvelope.encode(type: .dashboardSnapshot, payload: snapshot)
        do {
            try WCSession.default.updateApplicationContext(payload)
        } catch {
            log.error("updateApplicationContext failed: \(error.localizedDescription)")
        }
    }

    /// Sends a single high-severity alert as a high-priority message so the watch
    /// can fire a local notification right away. Falls back to transferUserInfo
    /// (queued, delivered when the watch wakes) if it isn't currently reachable.
    func notifyHighSeverityAlert(_ alert: WazuhAlert) {
        let payload = WCEnvelope.encode(type: .highSeverityAlert, payload: alert)
        let session = WCSession.default
        if session.isReachable {
            session.sendMessage(payload, replyHandler: nil) { [weak self] error in
                self?.log.error("sendMessage failed, falling back to transferUserInfo: \(error.localizedDescription)")
                session.transferUserInfo(payload)
            }
        } else {
            session.transferUserInfo(payload)
        }
    }

    // MARK: WCSessionDelegate

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async { self.watchIsReachable = session.isReachable }
    }

    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) { session.activate() }

    func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async { self.watchIsReachable = session.isReachable }
    }

    /// The watch can ask us to refresh on-demand (e.g. pull-to-refresh in DashboardView).
    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        guard WCEnvelope.decodeType(from: message) == .requestRefresh else { return }
        Task {
            await PollingCoordinator.shared.pollOnce(reason: "watch requested refresh")
        }
    }
}
