//
//  SettingsView.swift
//  iOS target only
//

import SwiftUI

struct SettingsView: View {
    @State private var managerHost: String = WazuhCredentialStore.managerHost ?? "https://your-wazuh-manager:55000"
    @State private var indexerHost: String = WazuhCredentialStore.indexerHost ?? "https://your-wazuh-indexer:9200"
    @State private var username: String = WazuhCredentialStore.username ?? ""
    @State private var password: String = WazuhCredentialStore.password ?? ""
    @State private var threshold: Double = Double(WazuhCredentialStore.severityThreshold)
    @State private var savedBanner = false

    var body: some View {
        NavigationView {
            Form {
                Section("Wazuh Manager API") {
                    TextField("https://host:55000", text: $managerHost)
                        .keyboardType(.URL).autocapitalization(.none)
                }
                Section("Wazuh Indexer API") {
                    TextField("https://host:9200", text: $indexerHost)
                        .keyboardType(.URL).autocapitalization(.none)
                    Text("Alert content is read from the Indexer, not the Manager API.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Credentials") {
                    TextField("Username", text: $username).autocapitalization(.none)
                    SecureField("Password", text: $password)
                }
                Section("Notifications") {
                    VStack(alignment: .leading) {
                        Text("Notify at rule level ≥ \(Int(threshold)) (\(AlertSeverity.from(level: Int(threshold)).label))")
                        Slider(value: $threshold, in: 0...15, step: 1)
                    }
                }
                Section {
                    Button("Save") { save() }
                    if savedBanner {
                        Text("Saved.").foregroundStyle(.green)
                    }
                }
            }
            .navigationTitle("Settings")
        }
    }

    private func save() {
        WazuhCredentialStore.managerHost = managerHost
        WazuhCredentialStore.indexerHost = indexerHost
        WazuhCredentialStore.username = username
        WazuhCredentialStore.password = password
        WazuhCredentialStore.severityThreshold = Int(threshold)
        savedBanner = true
        Task { await PollingCoordinator.shared.pollOnce(reason: "settings saved") }
    }
}

#Preview {
    SettingsView()
}
