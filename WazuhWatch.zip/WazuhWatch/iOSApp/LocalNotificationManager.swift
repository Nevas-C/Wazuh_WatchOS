//
//  LocalNotificationManager.swift
//  iOS target only
//

import Foundation
import UserNotifications

final class LocalNotificationManager {
    static let shared = LocalNotificationManager()

    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    func postAlertNotification(for alert: WazuhAlert) {
        let content = UNMutableNotificationContent()
        content.title = "\(alert.severity.label) severity alert"
        content.subtitle = alert.agentName
        content.body = alert.ruleDescription
        content.sound = .defaultCritical
        content.userInfo = ["alertId": alert.id]

        let request = UNNotificationRequest(identifier: alert.id, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}
