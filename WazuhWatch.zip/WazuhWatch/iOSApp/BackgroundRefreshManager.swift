//
//  BackgroundRefreshManager.swift
//  iOS target only
//
//  iOS's BGTaskScheduler is opportunistic — the system decides when (and
//  whether) to actually run this, typically not more often than every
//  15-30 min, less when the phone is idle/low on battery. It's a backstop,
//  not a real-time channel. Foreground polling (the app open, or a timer
//  while active) plus this background task together give reasonably fresh
//  data without needing a push-notification backend.
//

import Foundation
import BackgroundTasks

enum BackgroundRefreshManager {
    static let taskIdentifier = "com.yourorg.wazuhwatch.refresh"

    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskIdentifier, using: nil) { task in
            handle(task: task as! BGAppRefreshTask)
        }
    }

    static func schedule() {
        let request = BGAppRefreshTaskRequest(identifier: taskIdentifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        try? BGTaskScheduler.shared.submit(request)
    }

    private static func handle(task: BGAppRefreshTask) {
        schedule() // always reschedule the next one immediately

        let work = Task {
            await PollingCoordinator.shared.pollOnce(reason: "background refresh")
            task.setTaskCompleted(success: true)
        }
        task.expirationHandler = {
            work.cancel()
        }
    }
}
